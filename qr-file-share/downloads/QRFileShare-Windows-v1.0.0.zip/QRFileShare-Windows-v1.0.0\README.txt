QR File Share for Windows
=========================

Version 1.0.0

HOW TO RUN
----------
1. Unzip this whole folder somewhere (Desktop is fine).
   Keep every file together - the .exe will not start on its own.
2. Double-click qr_file_share.exe

Windows may warn that the publisher is unknown, because this build is not
code-signed. Choose "More info" then "Run anyway" if you trust the source.

HOW TO USE IT
-------------
1. Make sure your PC and your phone are on the SAME Wi-Fi network,
   or connect your PC to your phone's hotspot.
2. On the PC, click CREATE QR. A code and an address appear.
3. On the phone, open QR File Share and tap SCAN QR, then scan the code.
4. Once paired, either device can send files or a whole folder.

If your PC has several network adapters (VirtualBox, WSL, VPN), check that
the address shown under the QR code is your real Wi-Fi address. If it is not,
use ENTER ADDRESS on the phone side instead and type the correct one.

NOTES
-----
- Transfers happen directly over your local network. Nothing is uploaded.
- Transfers are not encrypted, so use it on networks you trust.
- The PC cannot scan QR codes (no camera support on Windows), so the PC
  always shows the code and the phone scans it.
